import HomeScreen from "@/src/screens/HomeScreen";

const Page = () => {
  return (
    <div>
        <HomeScreen />
    </div>
  );
};

export default Page;
